/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import webservice.EstudianteVO;

/**
 *
 * @author kevin
 */
public class Estudiante {
    
    public Estudiante(){}

    public java.util.List<webservice.EstudianteVO> mostrar() {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.mostrar();
    }

    public EstudianteVO insetar(java.lang.String nombre, java.lang.String apellido, int edad, java.lang.String nacionalidad, int punteo) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.insetar(nombre, apellido, edad, nacionalidad, punteo);
    }

    public EstudianteVO eliminar(int id) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.eliminar(id);
    }

   public EstudianteVO consultaID(int id) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.consultaID(id);
    }

    public EstudianteVO modificar(int id, java.lang.String nombre, java.lang.String apellido, int edad, java.lang.String nacionalidad, int punteo) {
        webservice.Service_Service service = new webservice.Service_Service();
        webservice.Service port = service.getServicePort();
        return port.modificar(id, nombre, apellido, edad, nacionalidad, punteo);
    }
    
    
    
    
    
}
